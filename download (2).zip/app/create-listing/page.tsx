import CreateListingForm from '@/components/listings/create-listing-form';

export default function CreateListingPage() {
  return (
    <div className="container mx-auto py-8">
      <CreateListingForm />
    </div>
  );
}
