import { config } from 'dotenv';
config();

import '@/ai/flows/suggest-pickup-time.ts';
import '@/ai/flows/suggest-food-description.ts';
